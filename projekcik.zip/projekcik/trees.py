"""
Moduł odpowiedzialny za bazy danych powiązane ze strukturami drzewiastymi (odpytania).

Zawiera implementacje:
1. Drzewa Zrównoważonego typu AVL do błyskawicznych opcji i zapisu, wspierającego m.in rotacje (LL, LR, RL, RR) 
   lub jego wariantu binarnego zapytaniowego np. drzewo BST.
"""

class DrzewoPrzedzialowe:
    def __init__(self, krasnoludki):
        self.n = len(krasnoludki)
        self.krasnoludki = krasnoludki
        # Tworzymy tablicę na drzewo. Rozmiar 4*N to sprawdzony standard, 
        # który bezpiecznie pomieści wszystkie węzły drzewa binarnego.
        self.tree = [None] * (4 * self.n)
        
        # Jeśli lista nie jest pusta, budujemy drzewo (Preprocessing w O(N))
        if self.n > 0:
            self._build(1, 0, self.n - 1)

    def _build(self, node, start, end):
        # Krok podstawowy: zeszliśmy do liścia (pojedynczy krasnoludek na granicy)
        if start == end:
            self.tree[node] = self.krasnoludki[start]
        else:
            mid = (start + end) // 2
            left_child = 2 * node
            right_child = 2 * node + 1
            
            # Rekurencyjnie budujemy lewe i prawe poddrzewo
            self._build(left_child, start, mid)
            self._build(right_child, mid + 1, end)
            
            # Kto jest głośniejszy - dzieciak po lewej czy po prawej?
            # Wygranego przypisujemy do aktualnego węzła rodzica
            if self.tree[left_child].glosnosc >= self.tree[right_child].glosnosc:
                self.tree[node] = self.tree[left_child]
            else:
                self.tree[node] = self.tree[right_child]

    def znajdz_najglosniejszego(self, q_start, q_end):
        """
        Zwraca obiekt Krasnoludka z najwyższą głośnością na przedziale indeksów.
        Obsługuje zapytania cykliczne (gdy granica jest zamkniętym okręgiem i q_start > q_end).
        Złożoność: O(log N)
        """
        if self.n == 0:
            return None # Zabezpieczenie przed pustą tablicą
            
        # Zabezpieczenie indeksów (modulo), żeby nie wyjść poza tablicę
        q_start = q_start % self.n
        q_end = q_end % self.n

        # Przypadek 1: Standardowe zapytanie (np. odcinek 2 do 5)
        if q_start <= q_end:
            return self._query(1, 0, self.n - 1, q_start, q_end)
            
        # Przypadek 2: Zapytanie cykliczne (np. odcinek 5 do 2 na granicy o długości 6)
        else:
            # Szukamy maksimum na końcówce tablicy...
            wynik_koncowka = self._query(1, 0, self.n - 1, q_start, self.n - 1)
            # ...oraz maksimum na początku tablicy
            wynik_poczatek = self._query(1, 0, self.n - 1, 0, q_end)
            
            # Zabezpieczenia na wypadek, gdyby któraś część zwróciła None
            if wynik_koncowka is None: return wynik_poczatek
            if wynik_poczatek is None: return wynik_koncowka
            
            # Porównujemy wygranych z obu części i zwracamy głośniejszego
            if wynik_koncowka.glosnosc >= wynik_poczatek.glosnosc:
                return wynik_koncowka
            else:
                return wynik_poczatek

    def _query(self, node, start, end, q_start, q_end):
        # Przypadek 1: Rozpatrywany przedział drzewa leży CAŁKOWICIE POZA zapytaniem
        if q_start > end or q_end < start:
            return None
        
        # Przypadek 2: Rozpatrywany przedział drzewa leży CAŁKOWICIE WNĘTRZU zapytania
        # (Nie musimy schodzić niżej, od razu zwracamy zwycięzcę tego przedziału!)
        if q_start <= start and end <= q_end:
            return self.tree[node]
        
        # Przypadek 3: Pokrycie jest CZĘŚCIOWE, więc schodzimy głębiej do dzieci
        mid = (start + end) // 2
        left_result = self._query(2 * node, start, mid, q_start, q_end)
        right_result = self._query(2 * node + 1, mid + 1, end, q_start, q_end)
        
        # Porównujemy wyniki z dzieci i zwracamy lepszego
        if left_result is None: return right_result
        if right_result is None: return left_result
        
        if left_result.glosnosc >= right_result.glosnosc:
            return left_result
        else:
            return right_result
