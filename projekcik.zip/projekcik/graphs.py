"""
Moduł odpowiedzialny za algorytmy sieciowe i grafowe.
Implementuje logikę opartą na listach sąsiedztwa i reprezentacji macierzowej.

Zawiera implementacje:
1. Algorytmu Dinica - służącego do wyznaczania maksymalnego przepływu (maksymalizacja wydobycia).
2. Algorytmu Busackera-Gowena (minimalny koszt maksymalnego przepływu)
   z algorytmem Moore'a-Bellmana ze stosowną poprawką w celu rozwiązywania najkrótszych dróg przy ujemnych koszcie.
"""
import math
from collections import deque

# Algorytm Dinica (MKM)
class DinicMKM:
    def __init__(self, n: int):
        self.n = n
        self.graf = [[] for _ in range(n)] # Lista sasiedztwa
        self.poziom = [-1] * n

    def dodaj_krawedz(self, u: int, v: int, przepustowosc: int):
        self.graf[u].append([v, przepustowosc, 0, len(self.graf[v])]) # u - punkt startowy
        self.graf[v].append([u, 0, 0, len(self.graf[u]) - 1]) # v - punkt docelowy

    def _bfs(self, zrodlo: int, ujscie: int):
        self.poziom = [-1] * self.n
        self.poziom[zrodlo] = 0
        kolejka = deque([zrodlo])
        while kolejka:
            u = kolejka.popleft()
            for v, przepustowosc, przeplyw, id_powrotnej in self.graf[u]:
                if przepustowosc - przeplyw > 0 and self.poziom[v] == -1:
                    self.poziom[v] = self.poziom[u] + 1
                    kolejka.append(v)
        return self.poziom[ujscie] != -1

    def _mkm_przeplyw_blokujacy(self, zrodlo: int, ujscie: int):
        pot_we = [0] * self.n
        pot_wy = [0] * self.n
        aktywny = [False] * self.n # Dany punkt ma przypisane pietro przez BFS
        for u in range(self.n):
            if self.poziom[u] != -1:
                aktywny[u] = True
                for v, przepustowosc, przeplyw, id_powrotnej in self.graf[u]:
                    if przepustowosc - przeplyw > 0 and self.poziom[v] == self.poziom[u] + 1:
                        pot_wy[u] += przepustowosc - przeplyw
                        pot_we[v] += przepustowosc - przeplyw
        pot_we[zrodlo] = math.inf
        pot_wy[ujscie] = math.inf
        calkowity_przeplyw = 0
        # Szukanie waskiego gardla
        while True:
            min_potencjal = math.inf
            wezel_od = -1
            for i in range(self.n):
                if aktywny[i]:
                    potencjal = min(pot_we[i], pot_wy[i])
                    if potencjal < min_potencjal:
                        min_potencjal = potencjal
                        wezel_od = i # Wezel odniesienia
            if wezel_od == -1 or min_potencjal == math.inf:
                break
            if min_potencjal <= 0:
                self._usun_wezel(wezel_od, aktywny, pot_we, pot_wy)
                continue
            f = min_potencjal
            calkowity_przeplyw += f
            nadmiar = [0] * self.n
            nadmiar[wezel_od] = f
            for l in range(self.poziom[wezel_od], self.poziom[ujscie]):
                for u in range(self.n):
                    if aktywny[u] and self.poziom[u] == l and nadmiar[u] > 0:
                        p = nadmiar[u]
                        for krawedz in self.graf[u]:
                            v, przepustowosc, przeplyw, id_powrotnej = krawedz
                            if aktywny[v] and self.poziom[v] == l + 1:
                                zapas = przepustowosc - przeplyw
                                if zapas > 0:
                                    w = min(p, zapas)
                                    krawedz[2] += w
                                    self.graf[v][id_powrotnej][2] -= w
                                    nadmiar[v] += w
                                    p -= w
                                    pot_wy[u] -= w
                                    pot_we[v] -= w
                                    if p == 0: break
            nadmiar = [0] * self.n
            nadmiar[wezel_od] = f
            for l in range(self.poziom[wezel_od], 0, -1):
                for u in range(self.n):
                    if aktywny[u] and self.poziom[u] == l and nadmiar[u] > 0:
                        p = nadmiar[u]
                        for krawedz in self.graf[u]:
                            v, przepustowosc, przeplyw, id_powrotnej = krawedz
                            if aktywny[v] and self.poziom[v] == l - 1:
                                krawedz_glowna = self.graf[v][id_powrotnej]
                                zapas = krawedz_glowna[1] - krawedz_glowna[2]
                                if zapas > 0:
                                    d = min(p, zapas)
                                    krawedz_glowna[2] += d
                                    krawedz[2] -= d
                                    nadmiar[v] += d
                                    p -= d
                                    pot_wy[v] -= d
                                    pot_we[u] -= d
                                    if p == 0: break
            self._usun_wezel(wezel_od, aktywny, pot_we, pot_wy)
        return calkowity_przeplyw

    def _usun_wezel(self, wezel_startowy: int, aktywny: list[bool], pot_we: list[int], pot_wy: list[int]):
        kolejka = deque([wezel_startowy])
        aktywny[wezel_startowy] = False
        while kolejka:
            obecny = kolejka.popleft()
            for krawedz in self.graf[obecny]:
                v, przepustowosc, przeplyw, id_powrotnej = krawedz
                if self.poziom[v] == self.poziom[obecny] + 1:
                    zapas = przepustowosc - przeplyw
                    if zapas > 0:
                        pot_we[v] -= zapas
                        if aktywny[v] and (pot_we[v] <= 0 or pot_wy[v] <= 0):
                            aktywny[v] = False
                            kolejka.append(v)
                elif self.poziom[v] == self.poziom[obecny] - 1:
                    krawedz_glowna = self.graf[v][id_powrotnej]
                    zapas = krawedz_glowna[1] - krawedz_glowna[2]
                    if zapas > 0:
                        pot_wy[v] -= zapas
                        if aktywny[v] and (pot_we[v] <= 0 or pot_wy[v] <= 0):
                            aktywny[v] = False
                            kolejka.append(v)

    def maksymalny_przeplyw(self, zrodlo: int, ujscie: int):
        przeplyw_suma = 0
        while self._bfs(zrodlo, ujscie):
            przeplyw_suma += self._mkm_przeplyw_blokujacy(zrodlo, ujscie)
        return przeplyw_suma


# Algorytm Busackera-Gowena i Bellmana-Forda z poprawka D'Esopo-Pape
class BusackerGowen:
    def __init__(self, n):
        self.n = n
        self.graf = [[] for _ in range(n)]

    def dodaj_krawedz(self, u, v, przepustowosc, koszt):
        self.graf[u].append([v, przepustowosc, 0, koszt, len(self.graf[v])])
        self.graf[v].append([u, 0, 0, -koszt, len(self.graf[u]) - 1])

    def _moore_bellman_desopo_pape(self, zrodlo, ujscie):
        odleglosc = [math.inf] * self.n
        poprzednik_wezel = [-1] * self.n
        poprzednik_krawedz = [-1] * self.n
        status = [0] * self.n
        odleglosc[zrodlo] = 0
        kolejka = deque([zrodlo])
        status[zrodlo] = 1
        while kolejka:
            u = kolejka.popleft()
            status[u] = 2
            for i, krawedz in enumerate(self.graf[u]):
                v, przepustowosc, przeplyw, koszt, id_powrotnej = krawedz
                zapas = przepustowosc - przeplyw
                if zapas > 0 and odleglosc[v] > odleglosc[u] + koszt:
                    odleglosc[v] = odleglosc[u] + koszt
                    poprzednik_wezel[v] = u
                    poprzednik_krawedz[v] = i
                    if status[v] == 0:
                        kolejka.append(v)
                        status[v] = 1
                    elif status[v] == 2:
                        kolejka.appendleft(v)
                        status[v] = 1
        return odleglosc, poprzednik_wezel, poprzednik_krawedz

    def oblicz_min_koszt(self, zrodlo, ujscie, cel_przeplywu):
        aktualny_przeplyw = 0
        calkowity_koszt_owsianki = 0
        while aktualny_przeplyw < cel_przeplywu:
            odleglosc, pop_wezel, pop_krawedz = self._moore_bellman_desopo_pape(zrodlo, ujscie)
            if odleglosc[ujscie] == math.inf:
                break
            przeplyw_sciezki = cel_przeplywu - aktualny_przeplyw
            u = ujscie
            while u != zrodlo:
                p_wezel = pop_wezel[u]
                p_krawedz = pop_krawedz[u]
                v, przepustowosc, przeplyw, koszt, id_powrotnej = self.graf[p_wezel][p_krawedz]
                przeplyw_sciezki = min(przeplyw_sciezki, przepustowosc - przeplyw)
                u = p_wezel
            aktualny_przeplyw += przeplyw_sciezki
            calkowity_koszt_owsianki += przeplyw_sciezki * odleglosc[ujscie]
            u = ujscie
            while u != zrodlo:
                p_wezel = pop_wezel[u]
                p_krawedz = pop_krawedz[u]
                krawedz_glowna = self.graf[p_wezel][p_krawedz]
                id_powrotnej = krawedz_glowna[4]
                krawedz_glowna[2] += przeplyw_sciezki
                self.graf[u][id_powrotnej][2] -= przeplyw_sciezki
                u = p_wezel
        return calkowity_koszt_owsianki
