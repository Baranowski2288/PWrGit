Log zmian - 19.05.2026

Zrealizowane zadania:

Rozbudowa algorytmu RMQ o obsługę struktur cyklicznych (src/trees.py):

Zmodyfikowano główną metodę znajdz_najglosniejszego w klasie DrzewoPrzedzialowe, aby obsługiwała granicę królestwa jako zamknięty okrąg.

Zaimplementowano logikę podziału zapytań brzegowych (gdzie q_start > q_end) na dwa niezależne podzapytania (od początku tablicy oraz do końca tablicy), zachowując logarytmiczną złożoność czasową.

Integracja algorytmu Grahama z logiką strażników (src/generator.py):

Dodano import funkcji graham z modułu geometrii obliczeniowej do silnika generatora.

Stworzono funkcję wyznacz_wieze_straznicze, która dynamicznie wylicza współrzędne środków krawędzi otoczki wypukłej.

Utworzono nową, elitarną sub-klasę krasnoludków pełniących rolę "Dekametrowców", posiadających unikalną umiejętność "obrona_granicy" (izolacja od algorytmów Dinica/Busackera-Gowena) oraz gwarantowaną wysoką donośność głosu (w przedziale 70-100).

Przydzielono strażnikom wysokie indeksy (od 9000), aby zapobiec konfliktom ID ze zwykłymi górnikami.

Przebudowa przepływu generowania zestawów danych (generuj_zestaw):

Zmodyfikowano kolejność (pipeline) generowania środowiska: generacja kopalni → wyliczenie otoczki granicznej → rozstawienie strażników na wieżach → wygenerowanie zwykłych górników.

Skorygowano funkcję odpowiedzialną za generowanie ataków jabłkami (generuj_ataki_na_granice), aby celowała wyłącznie w indeksy przypisane nowym strażnikom granicznym.

Zintegrowano proces zapisu, dodając połączoną pulę wszystkich krasnoludków do struktury wynikowej pliku JSON.