import math
from graphs import DinicMKM, BusackerGowen

def oblicz_odleglosc(krasnal, kopalnia):
    return math.hypot(krasnal['x'] - kopalnia['x'], krasnal['y'] - kopalnia['y'])

def rozwiaz_problem_przydzialu(dane_json):
    krasnoludki = dane_json['krasnoludki']
    kopalnie = dane_json['kopalnie']
    v_krasnali = len(krasnoludki)
    v_kopalni = len(kopalnie)
    n = v_krasnali + v_kopalni + 2
    zrodlo = 0
    ujscie = n - 1
    dinic = DinicMKM(n)
    for i, krasnal in enumerate(krasnoludki):
        id_k = i + 1
        dinic.dodaj_krawedz(zrodlo, id_k, 1)
        for j, kopalnia in enumerate(kopalnie):
            id_kop = v_krasnali + j + 1
            if kopalnia['mineral'] in krasnal['umiejetnosci']:
                dinic.dodaj_krawedz(id_k, id_kop, 1)
    for j, kopalnia in enumerate(kopalnie):
        id_kop = v_krasnali + j + 1
        dinic.dodaj_krawedz(id_kop, ujscie, kopalnia['wydajnosc'])
    maksymalny_przeplyw = dinic.maksymalny_przeplyw(zrodlo, ujscie)


    bg = BusackerGowen(n)
    for i, krasnal in enumerate(krasnoludki):
        id_k = i + 1
        bg.dodaj_krawedz(zrodlo, id_k, 1, 0.0)
        for j, kopalnia in enumerate(kopalnie):
            id_kop = v_krasnali + j + 1
            if kopalnia['mineral'] in krasnal['umiejetnosci']:
                dystans = oblicz_odleglosc(krasnal, kopalnia)
                bg.dodaj_krawedz(id_k, id_kop, 1, dystans)
    for j, kopalnia in enumerate(kopalnie):
        id_kop = v_krasnali + j + 1
        bg.dodaj_krawedz(id_kop, ujscie, kopalnia['wydajnosc'], 0.0)
    minimalny_koszt = bg.oblicz_min_koszt(zrodlo, ujscie, maksymalny_przeplyw)
    return maksymalny_przeplyw, minimalny_koszt
