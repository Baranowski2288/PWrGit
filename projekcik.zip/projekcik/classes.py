class Kopalnia:
    def __init__(self, id_kopalni, nazwa, x, y, wydajnosc, mineral):
        self.id = id_kopalni
        self.nazwa = nazwa
        self.x = x
        self.y = y
        self.wydajnosc = wydajnosc
        self.mineral = mineral
    # Funkcja do czytelnego wyswietlania reprezentacji kopalni
    def __repr__(self):
        return f"Kopalnia({self.nazwa}, x={self.x}, y={self.y}, wyd={self.wydajnosc})"

class Krasnoludek:
    def __init__(self, id_krasnala, imie, x, y, umiejetnosci, glosnosc=50):
        self.id = id_krasnala
        self.imie = imie
        self.x = x
        self.y = y
        self.umiejetnosci = set(umiejetnosci)
        self.glosnosc = glosnosc

    def __repr__(self):
        return f"Krasnoludek({self.imie}, x={self.x}, y={self.y}, glosnosc={self.glosnosc})"
