"""
Generator danych testowych: krasnoludki i kopalnie.
Tworzy zestawy danych o zadanym rozmiarze i zapisuje je do JSON w folderze data/.
"""
import json
import random
import math
import os
import argparse
try:
    from .classes import Krasnoludek, Kopalnia   # import pakietowy (z gui.py)
except ImportError:
    from classes import Krasnoludek, Kopalnia     # uruchomienie bezposrednie
try:
    from .geometry import graham
except ImportError:
    from geometry import graham


# Pule danych do losowania
MINERALY = [
    "zloto", "srebro", "miedz", "zelazo", "diament",
    "szmaragd", "rubin", "szafir", "wegiel", "platyna",
    "cynk", "olow", "cyna", "nikiel", "kobalt"
]

IMIONA = [
    "Apsik", "Gapcio", "Gburek", "Wesoly", "Spioch", "Mędrek", "Nieśmiałek",
    "Brok", "Grotek", "Kiloł", "Drobek", "Ryjek", "Kudłacz", "Siwy", "Hałaśnik",
    "Mruk", "Zuch", "Dłubek", "Pchełka", "Pazur", "Łomot", "Gwizdek", "Strzała",
    "Kubeł", "Kasztan", "Migdał", "Twardziel", "Iskra", "Młotek", "Kleszcz",
    "Bryła", "Kryształ", "Opal", "Granat", "Topaz", "Bursztyn", "Krzemień",
    "Łupek", "Bazalt", "Obsydian", "Pumeks", "Chalcedon", "Agat", "Jaspis"
]

NAZWY_KOPALN = [
    "Czarna Sztolnia", "Srebrna Żyła", "Złoty Szyb", "Głęboka Chodnia",
    "Żelazna Jama", "Kryształowa Grota", "Miedziany Przodek", "Szmaragdowy Tunel",
    "Rubinowy Korytarz", "Szafirowa Komnata", "Węglowa Galeria", "Platynowy Lej",
    "Cynkowa Dolina", "Ołowiany Szyb", "Cynowy Chodnik", "Niklowa Brama",
    "Kobaltowe Wrota", "Diamentowy Dół", "Kamienna Pieczara", "Bazaltowa Hala",
    "Kwarc Północny", "Południowy Przodek", "Wschodnia Sztolnia", "Zachodnia Komora"
]

# Zakres mapy (wspolrzedne)
MAPA_MIN = 0
MAPA_MAX = 10000


def generuj_kopalnie(n: int, seed: int = None) -> list[Kopalnia]:
    if seed is not None:
        random.seed(seed)

    kopalnie = []
    for i in range(n):
        nazwa = random.choice(NAZWY_KOPALN)

        kopalnia = Kopalnia(
            id_kopalni=i,
            nazwa=nazwa,
            x=random.randint(MAPA_MIN, MAPA_MAX),
            y=random.randint(MAPA_MIN, MAPA_MAX),
            wydajnosc=random.randint(1, 10),
            mineral=random.choice(MINERALY)
        )
        kopalnie.append(kopalnia)
    return kopalnie


def generuj_krasnoludki(n: int, kopalnie: list[Kopalnia], seed: int = None) -> list[Krasnoludek]:
    if seed is not None:
        random.seed(seed)

    dostepne_mineraly = list({k.mineral for k in kopalnie}) if kopalnie else MINERALY[:5]
    krasnoludki = []
    
    for i in range(n):
        imie = random.choice(IMIONA)
        ile_umiejetnosci = random.randint(1, min(3, len(dostepne_mineraly)))
        umiejetnosci = random.sample(dostepne_mineraly, ile_umiejetnosci)

        # NOWE: Losujemy głośność od 1 do 100
        glosnosc = random.randint(1, 100)

        # Upewnij się, że Twoja klasa w classes.py przyjmuje argument glosnosc!
        krasnoludek = Krasnoludek(
            id_krasnala=i,
            imie=imie,
            x=random.randint(MAPA_MIN, MAPA_MAX),
            y=random.randint(MAPA_MIN, MAPA_MAX),
            umiejetnosci=umiejetnosci,
            glosnosc=glosnosc # <--- DODANO
        )
        krasnoludki.append(krasnoludek)
    return krasnoludki
    
def generuj_ataki_na_granice(n_krasnali: int, liczba_atakow: int, seed: int = None):
    """Generuje listę zapytań [start, end] dla ataków na granicę."""
    if seed is not None:
        random.seed(seed)
        
    ataki = []
    for _ in range(liczba_atakow):
        # Losujemy początek i koniec przedziału (od 0 do n_krasnali - 1)
        start = random.randint(0, n_krasnali - 1)
        end = random.randint(start, n_krasnali - 1)
        ataki.append([start, end])
    return ataki
def _odleglosc(x1, y1, x2, y2):
    return round(math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2))


def generuj_polaczenia(kopalnie: list[Kopalnia], krasnoludki: list[Krasnoludek],
                       gestosc: float = 0.3, seed: int = None):
    """
    Generuje graf polaczen (drog) miedzy wszystkimi wezlami.
    Indeksowanie: kopalnie 0..m-1, krasnoludki m..m+k-1.
    gestosc (0.0-1.0) - prawdopodobienstwo istnienia krawedzi miedzy para wezlow.
    Zwraca (macierz_sasiedztwa, lista_sasiedztwa, mapowanie_wezlow).
    """
    if seed is not None:
        random.seed(seed)

    m = len(kopalnie)
    k = len(krasnoludki)
    n = m + k

    # Zbieramy wspolrzedne wszystkich wezlow
    # Indeksy: 0..m-1 = kopalnie, m..m+k-1 = krasnoludki
    wezly = []
    mapowanie = []
    for kop in kopalnie:
        wezly.append((kop.x, kop.y))
        mapowanie.append({"indeks": len(mapowanie), "typ": "kopalnia",
                          "id_oryginalny": kop.id, "nazwa": kop.nazwa})
    for kr in krasnoludki:
        wezly.append((kr.x, kr.y))
        mapowanie.append({"indeks": len(mapowanie), "typ": "krasnoludek",
                          "id_oryginalny": kr.id, "nazwa": kr.imie})

    # Macierz sasiedztwa (0 = brak polaczenia)
    macierz = [[0] * n for _ in range(n)]

    # Lista sasiedztwa
    lista = [[] for _ in range(n)]

    for i in range(n):
        for j in range(i + 1, n):
            if random.random() < gestosc:
                waga = _odleglosc(wezly[i][0], wezly[i][1],
                                  wezly[j][0], wezly[j][1])
                if waga == 0:
                    waga = 1
                macierz[i][j] = waga
                macierz[j][i] = waga
                lista[i].append({"sasiad": j, "waga": waga})
                lista[j].append({"sasiad": i, "waga": waga})

    return macierz, lista, mapowanie


def polaczenia_do_dict(macierz, lista, mapowanie):
    return {
        "mapowanie_wezlow": mapowanie,
        "macierz_sasiedztwa": macierz,
        "lista_sasiedztwa": {str(i): sasiedzi for i, sasiedzi in enumerate(lista)}
    }


# Zaktualizuj do_dict
def do_dict(kopalnie: list[Kopalnia], krasnoludki: list[Krasnoludek],
            polaczenia: dict = None, ataki: list = None) -> dict: # <--- Dodano ataki
    dane = {
        # ... kopalnie zostają bez zmian ...
        "krasnoludki": [
            {
                "id": kr.id,
                "imie": kr.imie,
                "x": kr.x,
                "y": kr.y,
                "umiejetnosci": list(kr.umiejetnosci),
                "glosnosc": kr.glosnosc # <--- DODANO
            }
            for kr in krasnoludki
        ]
    }
    if polaczenia is not None:
        dane["polaczenia"] = polaczenia
    if ataki is not None:
        dane["ataki"] = ataki # <--- DODANO
    return dane

def zapisz_dane(dane: dict, nazwa_pliku: str):
    sciezka_data = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")
    os.makedirs(sciezka_data, exist_ok=True)
    sciezka = os.path.join(sciezka_data, nazwa_pliku)
    with open(sciezka, "w", encoding="utf-8") as f:
        json.dump(dane, f, ensure_ascii=False, indent=2)
    print(f"Zapisano dane do: {sciezka}")
    return sciezka


def wczytaj_dane(nazwa_pliku: str):
    sciezka_data = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")
    sciezka = os.path.join(sciezka_data, nazwa_pliku)
    with open(sciezka, "r", encoding="utf-8") as f:
        dane = json.load(f)

    kopalnie = [
        Kopalnia(k["id"], k["nazwa"], k["x"], k["y"], k["wydajnosc"], k["mineral"])
        for k in dane["kopalnie"]
    ]
    krasnoludki = [
        Krasnoludek(kr["id"], kr["imie"], kr["x"], kr["y"], kr["umiejetnosci"])
        for kr in dane["krasnoludki"]
    ]

    polaczenia = dane.get("polaczenia", None)
    return kopalnie, krasnoludki, polaczenia


def wyznacz_wieze_straznicze(otoczka_kopaln):
    """Generuje elitarnych dekametrowców na podstawie otoczki."""
    straznicy = []
    n = len(otoczka_kopaln)
    
    if n < 3:
        return straznicy
        
    for i in range(n):
        k1 = otoczka_kopaln[i]
        k2 = otoczka_kopaln[(i + 1) % n]
        
        mid_x = int((k1.x + k2.x) / 2)
        mid_y = int((k1.y + k2.y) / 2)
        
        straznik = Krasnoludek(
            id_krasnala=9000 + i, 
            imie=f"Dekametrowiec_{i}",
            x=mid_x,
            y=mid_y,
            umiejetnosci=["obrona_granicy"], 
            glosnosc=random.randint(70, 100) 
        )
        straznicy.append(straznik)
        
    return straznicy

# Zaktualizowana funkcja generuj_zestaw:
def generuj_zestaw(n_kopaln: int, n_krasnali: int, gestosc: float = 0.3,
                   seed: int = 42, nazwa_pliku: str = None) -> str:
    # 1. Tworzymy kopalnie
    kopalnie = generuj_kopalnie(n_kopaln, seed=seed)
    
    # 2. Liczymy otoczkę wypukłą z kopalni (granica państwa)
    otoczka = graham(kopalnie)
    
    # 3. Rozstawiamy na granicy elitarnych strażników
    straznicy = wyznacz_wieze_straznicze(otoczka)
    
    # 4. Generujemy zwykłych krasnali-górników
    zwykli_krasnale = generuj_krasnoludki(n_krasnali, kopalnie, seed=seed + 1)
    
    # 5. Łączymy obie grupy w jedną listę (żeby GUI ich narysowało)
    krasnoludki = straznicy + zwykli_krasnale

    # --- Reszta funkcji zostaje bez zmian ---
    macierz, lista, mapowanie = generuj_polaczenia(
        kopalnie, krasnoludki, gestosc=gestosc, seed=seed + 2)
    polaczenia = polaczenia_do_dict(macierz, lista, mapowanie)

    ataki = generuj_ataki_na_granice(len(straznicy), liczba_atakow=50, seed=seed+3) # Atakujemy tylko wieże!

    dane = do_dict(kopalnie, krasnoludki, polaczenia, ataki)

    if nazwa_pliku is None:
        nazwa_pliku = f"dane_k{n_kopaln}_kr{n_krasnali}.json"

    return zapisz_dane(dane, nazwa_pliku)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generator danych testowych")
    parser.add_argument("--kopalnie", type=int, default=25, help="Liczba kopaln (domyslnie 5)")
    parser.add_argument("--krasnoludki", type=int, default=100, help="Liczba krasnoludkow (domyslnie 10)")
    parser.add_argument("--gestosc", type=float, default=0.3,
                        help="Gestosc polaczen 0.0-1.0 (domyslnie 0.3)")
    parser.add_argument("--seed", type=int, default=42, help="Ziarno generatora (domyslnie 42)")
    parser.add_argument("--plik", type=str, default=None, help="Nazwa pliku wyjsciowego")
    args = parser.parse_args()

    sciezka = generuj_zestaw(args.kopalnie, args.krasnoludki,
                             gestosc=args.gestosc, seed=args.seed,
                             nazwa_pliku=args.plik)

    # Podglad wygenerowanych danych
    kopalnie, krasnoludki, polaczenia = wczytaj_dane(os.path.basename(sciezka))
    print(f"\nWygenerowano {len(kopalnie)} kopaln i {len(krasnoludki)} krasnoludkow:")
    print("\nKopalnie:")
    for k in kopalnie[:5]:
        print(f"  {k}")
    if len(kopalnie) > 5:
        print(f"  ... i {len(kopalnie) - 5} wiecej")
    print("\nKrasnoludki:")
    for kr in krasnoludki[:5]:
        print(f"  {kr}")
    if len(krasnoludki) > 5:
        print(f"  ... i {len(krasnoludki) - 5} wiecej")

    if polaczenia:
        n_wezlow = len(polaczenia["mapowanie_wezlow"])
        n_krawedzi = sum(
            len(s) for s in polaczenia["lista_sasiedztwa"].values()) // 2
        print(f"\nPolaczenia: {n_wezlow} wezlow, {n_krawedzi} krawedzi"
              f" (gestosc={args.gestosc})")
