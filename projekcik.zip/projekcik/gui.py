import tkinter as tk
from tkinter import ttk, messagebox
import random
import math
import time

# Importy modułów
from classes import Krasnoludek, Kopalnia
from generator import generuj_kopalnie, generuj_krasnoludki, wyznacz_wieze_straznicze, generuj_ataki_na_granice
from geometry import graham
from trees import DrzewoPrzedzialowe
from graph_mapper import rozwiaz_problem_przydzialu
from PIL import Image, ImageTk


# Paleta barw (Motyw Natury: Kamień, Łąka, Niebo)
BG_MAIN = "#292524"     # Ciemny, twardy kamień (główne tło okna)
BG_PANEL = "#44403c"    # Jasny głaz / skała (panele boczne i okienka)
ACCENT = "#16a34a"      # Soczysta zieleń liści (główne przyciski)
TEXT_COLOR = "#f5f5f4"  # Wapienna, naturalna biel (tekst)
COLOR_MINE = "#d97706"  # Ciepły kolor drewna / gliny (kopalnie)
COLOR_DWARF = "#0ea5e9" # Jasny błękit nieba (górnicy)
COLOR_HULL = "#65a30d"  # Zieleń mchu (granica Grahama)
COLOR_LINK = "#bae6fd"  # Delikatny, wodny błękit (nici powiązań wyglądające jak wiatr/strumyki)


class NowaAplikacjaGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Królestwo Śnieżki 2026")
        self.root.geometry("1280x720")
        self.root.configure(bg=BG_MAIN)
        
        # Stan danych
        self.kopalnie = []
        self.krasnale_gornicy = []
        self.wieze_straznicy = []
        self.otoczka_punktow = []
        
        # Stan kamery (skalowanie i przesuwanie)
        self.zoom = 1.0
        self.pan_x = 0.0
        self.pan_y = 0.0
        self.pivot_x = 0
        self.pivot_y = 0
        
        # Stan selekcji ataku
        self.id_wygranego_straznika = None
        self.zaatakowane_wieze = []

        self._autorski_styl()
        
        # Kontenery na ekrany
        self.ekran_startowy = tk.Frame(self.root, bg=BG_MAIN)
        self.ekran_glowny = tk.Frame(self.root, bg=BG_MAIN)
        
# --- WCZYTYWANIE GRAFIK CUSTOMOWYCH ---
        try:
            # Image.NEAREST jest KLUCZOWE dla pixel-artu - sprawia, że przy skalowaniu obrazki pozostają ostre i nie rozmazują się
            self.img_kopalnia = ImageTk.PhotoImage(Image.open("assets/kopalnia.png").resize((64, 64), Image.NEAREST))
            self.img_gornik = ImageTk.PhotoImage(Image.open("assets/gornik.png").resize((32, 32), Image.NEAREST))
            self.img_wieza = ImageTk.PhotoImage(Image.open("assets/wieza.png").resize((64, 64), Image.NEAREST))
            self.img_wieza_atak = ImageTk.PhotoImage(Image.open("assets/wieza_atak.png").resize((64, 64), Image.NEAREST))
            self.img_tlo = ImageTk.PhotoImage(Image.open("assets/background.png").resize((1280, 720), Image.NEAREST))
            self.img_mapa = ImageTk.PhotoImage(Image.open("assets/mapa_tlo.png").resize((1920, 1080), Image.NEAREST))
        except Exception as e:
            # Fallback na wypadek, gdyby zapomniano dodać plików do folderuassets
            print(f"Nie znaleziono plików graficznych, używam standardowych kształtów: {e}")
            self.img_kopalnia = None

        self._buduj_menu_startowe()
        self._stworz_architekture_aplikacji()
        
        self.ekran_startowy.pack(fill=tk.BOTH, expand=True)

    def _autorski_styl(self):
        styl = ttk.Style()
        styl.theme_use("clam")
        styl.configure(".", background=BG_MAIN, foreground=TEXT_COLOR, font=("Segoe UI", 10))
        styl.configure("TFrame", background=BG_MAIN)
        styl.configure("Panel.TFrame", background=BG_PANEL)
        
        styl.configure("Accent.TButton", background=ACCENT, foreground="white", font=("Segoe UI", 10, "bold"), padding=5)
        styl.map("Accent.TButton", background=[("active", "#6d28d9")])
        
        styl.configure("Hero.TButton", background="#059669", foreground="white", font=("Segoe UI", 14, "bold"), padding=15)
        styl.map("Hero.TButton", background=[("active", "#047857")])
    # ==========================================
    #             EKRAN STARTOWY
    # ==========================================
    def _buduj_menu_startowe(self):
        # --- ZMIANA: Wklejamy obrazek tła ---
        if hasattr(self, 'img_tlo') and self.img_tlo:
            etykieta_tla = tk.Label(self.ekran_startowy, image=self.img_tlo)
            etykieta_tla.place(x=0, y=0, relwidth=1, relheight=1)

        # Nagłówek z ramką
        tk.Label(self.ekran_startowy, text="🍎 PROJEKT 2026: KRÓLESTWO ŚNIEŻKI 🍎", 
                 bg="#11111b", fg="#a78bfa", font=("Segoe UI", 28, "bold"), bd=5, relief=tk.RIDGE).pack(pady=(40, 20))
        
        # Formularz z ciemnym panelem (żeby się nie zlał z tłem)
        ramka_formularza = tk.Frame(self.ekran_startowy, bg=BG_PANEL, bd=2, relief=tk.SOLID, padx=20, pady=20)
        ramka_formularza.pack(expand=True)
        
        tk.Label(ramka_formularza, text="Skonfiguruj parametry symulacji:", 
                 bg=BG_PANEL, fg=TEXT_COLOR, font=("Segoe UI", 14)).grid(row=0, column=0, columnspan=2, pady=(0, 20))
        
        # ... (tutaj zostawiasz swoje tk.Spinbox tak jak były) ...    
        # Poprawka 1: tk.Spinbox zamiast ttk.Spinbox gwarantuje czytelność tekstu w Dark Mode
        tk.Label(ramka_formularza, text="Liczba kopalń:", bg=BG_MAIN, fg=TEXT_COLOR, font=("Segoe UI", 12)).grid(row=1, column=0, sticky=tk.E, padx=10, pady=10)
        self.zmienna_kopalnie = tk.IntVar(value=15)
        tk.Spinbox(ramka_formularza, from_=3, to=100, textvariable=self.zmienna_kopalnie, width=10, 
                   font=("Segoe UI", 12), bg=BG_PANEL, fg=TEXT_COLOR, insertbackground=TEXT_COLOR, relief=tk.FLAT).grid(row=1, column=1, sticky=tk.W, pady=10)
        
        tk.Label(ramka_formularza, text="Liczba zwykłych krasnoludków:", bg=BG_MAIN, fg=TEXT_COLOR, font=("Segoe UI", 12)).grid(row=2, column=0, sticky=tk.E, padx=10, pady=10)
        self.zmienna_gornicy = tk.IntVar(value=50)
        tk.Spinbox(ramka_formularza, from_=5, to=500, textvariable=self.zmienna_gornicy, width=10, 
                   font=("Segoe UI", 12), bg=BG_PANEL, fg=TEXT_COLOR, insertbackground=TEXT_COLOR, relief=tk.FLAT).grid(row=2, column=1, sticky=tk.W, pady=10)
        
        ttk.Button(ramka_formularza, text="ZBUDUJ ŚWIAT I PRZEJDŹ DO PANELU 🚀", style="Hero.TButton", 
                   command=self._start_z_menu).grid(row=3, column=0, columnspan=2, pady=40)

    def _start_z_menu(self):
        ile_kop = self.zmienna_kopalnie.get()
        ile_gorn = self.zmienna_gornicy.get()
        
        self.kopalnie = generuj_kopalnie(ile_kop, seed=None)
        self.krasnale_gornicy = generuj_krasnoludki(ile_gorn, self.kopalnie, seed=None)
        
        self.wieze_straznicy = []
        self.otoczka_punktow = []
        self.id_wygranego_straznika = None
        self.zaatakowane_wieze = []
        
        self.ekran_startowy.pack_forget()
        self.ekran_glowny.pack(fill=tk.BOTH, expand=True)
        
        self.log(f"✨ Zbudowano świat: {ile_kop} kopalń, {ile_gorn} górników.")
        self.odswiez_mape()

    # ==========================================
    #             EKRAN GŁÓWNY (APLIKACJA)
    # ==========================================
    def _stworz_architekture_aplikacji(self):
        panel_lewy = ttk.Frame(self.ekran_glowny, style="Panel.TFrame", width=350)
        panel_lewy.pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=10)
        panel_lewy.pack_propagate(False)
        
        tk.Label(panel_lewy, text="⚙️ PANEL STRATEGICZNY", bg=BG_PANEL, fg="#a78bfa", font=("Segoe UI", 12, "bold")).pack(pady=10)
        
        ttk.Button(panel_lewy, text="⬅ Wróć do Menu", command=self._wroc_do_menu).pack(fill=tk.X, padx=10, pady=(0, 15))
        
        # ---> NOWY PRZYCISK: Benchmark <---
        ttk.Button(panel_lewy, text="🚀 Testy Wydajnościowe (Miliony)", style="Accent.TButton", command=self._otworz_benchmark).pack(fill=tk.X, padx=10, pady=(0, 15))
        
        ramka_alg = tk.LabelFrame(panel_lewy, text="Strategia Królestwa", bg=BG_PANEL, fg=TEXT_COLOR)
        ramka_alg.pack(fill=tk.X, padx=10, pady=5)
        ttk.Button(ramka_alg, text="🛡️ Wyznacz Granicę i Wieże (Graham)", command=self._akcja_oblicz_granice).pack(fill=tk.X, padx=10, pady=10)
        
        self.ramka_ataku = tk.LabelFrame(panel_lewy, text="Symulacja Ataku Jabłkami", bg=BG_PANEL, fg=TEXT_COLOR)
        self.ramka_ataku.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Label(self.ramka_ataku, text="Indeks Wieży Startowej:", bg=BG_PANEL, fg=TEXT_COLOR).pack(anchor=tk.W, padx=10)
        self.skala_start = tk.Scale(self.ramka_ataku, from_=0, to=10, orient=tk.HORIZONTAL, bg=BG_PANEL, fg=TEXT_COLOR, highlightthickness=0)
        self.skala_start.pack(fill=tk.X, padx=10)
        
        tk.Label(self.ramka_ataku, text="Indeks Wieży Końcowej:", bg=BG_PANEL, fg=TEXT_COLOR).pack(anchor=tk.W, padx=10)
        self.skala_koniec = tk.Scale(self.ramka_ataku, from_=0, to=10, orient=tk.HORIZONTAL, bg=BG_PANEL, fg=TEXT_COLOR, highlightthickness=0)
        self.skala_koniec.pack(fill=tk.X, padx=10)
        
        ttk.Button(self.ramka_ataku, text="💥 Odpal Atak na Przedział", style="Accent.TButton", command=self._akcja_odpal_atak).pack(fill=tk.X, padx=10, pady=5)
        
        # Poprawka 2: Przycisk do losowania zakresu obrony granicy
        ttk.Button(self.ramka_ataku, text="🎲 Losuj i Odpal Atak", command=self._akcja_losowego_ataku).pack(fill=tk.X, padx=10, pady=(0, 10))

        tk.Label(panel_lewy, text="📋 Meldunki z frontu:", bg=BG_PANEL, fg=TEXT_COLOR).pack(anchor=tk.W, padx=10, pady=(10,0))
        self.konsola = tk.Text(panel_lewy, bg=BG_MAIN, fg="#a6e3a1", font=("Consolas", 9), relief=tk.FLAT, height=15)
        self.konsola.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.canvas = tk.Canvas(self.ekran_glowny, bg="#181825", highlightthickness=0)
        self.canvas.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.canvas.bind("<ButtonPress-1>", self._start_pan)
        self.canvas.bind("<B1-Motion>", self._execute_pan)
        self.canvas.bind("<MouseWheel>", self._execute_zoom)
        self.canvas.bind("<Configure>", lambda e: self.odswiez_mape())

    def _wroc_do_menu(self):
        self.ekran_glowny.pack_forget()
        self.ekran_startowy.pack(fill=tk.BOTH, expand=True)

    def log(self, tekst):
        self.konsola.insert(tk.END, tekst + "\n")
        self.konsola.see(tk.END)

    # ---- AKCJE I INTEGRACJA ALGORYTMÓW ----
    def _akcja_oblicz_granice(self):
        if not self.kopalnie: return
        self.otoczka_punktow = graham(self.kopalnie)
        self.wieze_straznicy = wyznacz_wieze_straznicze(self.otoczka_punktow)
        
        n_wiez = len(self.wieze_straznicy)
        if n_wiez > 0:
            self.skala_start.configure(to=n_wiez - 1)
            self.skala_koniec.configure(to=n_wiez - 1)
            
        self.log(f"🛡️ Graham wyznaczył wielokąt o {len(self.otoczka_punktow)} wierzchołkach.")
        self.log(f"-> Zbudowano {n_wiez} wież strażniczych na granicach.")
        self.odswiez_mape()

    def _akcja_losowego_ataku(self):
        if not self.wieze_straznicy:
            messagebox.showwarning("Brak obrony", "Wznieś najpierw wieże strażnicze!")
            return
        n = len(self.wieze_straznicy)
        q_start = random.randint(0, n - 1)
        q_end = random.randint(0, n - 1)
        self.skala_start.set(q_start)
        self.skala_koniec.set(q_end)
        self._akcja_odpal_atak()

    def _akcja_odpal_atak(self):
        if not self.wieze_straznicy: return
        q_start = self.skala_start.get()
        q_end = self.skala_koniec.get()
        
        drzewo = DrzewoPrzedzialowe(self.wieze_straznicy)
        najglosniejszy = drzewo.znajdz_najglosniejszego(q_start, q_end)
        
        self.zaatakowane_wieze = []
        n = len(self.wieze_straznicy)
        curr = q_start
        while True:
            self.zaatakowane_wieze.append(curr)
            if curr == q_end: break
            curr = (curr + 1) % n
            
        if najglosniejszy:
            self.id_wygranego_straznika = najglosniejszy.id
            self.log(f"💥 Atak na wieże [{q_start} do {q_end}].")
            self.log(f"-> {najglosniejszy.imie} ryczy głośnością {najglosniejszy.glosnosc}!")
            
        self.odswiez_mape()
        self._animuj_atak()

    # ---- SILNIK GRAFICZNY MAPY ----
    def _przelicz_koordynaty(self, x, y):
        szer = self.canvas.winfo_width()
        wys = self.canvas.winfo_height()
        margines = 50
        base_x = margines + (x / 10000.0) * (szer - 2 * margines)
        base_y = margines + (y / 10000.0) * (wys - 2 * margines)
        cx, cy = szer / 2, wys / 2
        px = cx + (base_x - cx) * self.zoom + self.pan_x
        py = cy + (base_y - cy) * self.zoom + self.pan_y
        return px, py

    def odswiez_mape(self):
        c = self.canvas
        c.delete("all")
        if c.winfo_width() < 10: return

        # ==========================================
        # WARSTWA 0: TŁO MAPY (Musi być jako absolutnie pierwsze!)
        # ==========================================
        if hasattr(self, 'img_mapa') and self.img_mapa:
            px_srodek, py_srodek = self._przelicz_koordynaty(5000, 5000)
            c.create_image(px_srodek, py_srodek, image=self.img_mapa)

        # ==========================================
        # WARSTWA 1: POWIĄZANIA (Nici)
        # ==========================================
        for kr in self.krasnale_gornicy:
            for k in self.kopalnie:
                if k.mineral in kr.umiejetnosci:
                    px1, py1 = self._przelicz_koordynaty(kr.x, kr.y)
                    px2, py2 = self._przelicz_koordynaty(k.x, k.y)
                    # Zwiększamy width do 2 i dodajemy styl przerywany (dash), żeby odcinały się od tła
                    c.create_line(px1, py1, px2, py2, fill=COLOR_LINK, width=2, dash=(4, 4))
        # 1. Otoczka
        if len(self.otoczka_punktow) >= 3:
            n = len(self.otoczka_punktow)
            for i in range(n):
                px1, py1 = self._przelicz_koordynaty(self.otoczka_punktow[i].x, self.otoczka_punktow[i].y)
                px2, py2 = self._przelicz_koordynaty(self.otoczka_punktow[(i+1)%n].x, self.otoczka_punktow[(i+1)%n].y)
                if i in self.zaatakowane_wieze:
                    c.create_line(px1, py1, px2, py2, fill="#ef4444", width=4)
                else:
                    c.create_line(px1, py1, px2, py2, fill=COLOR_HULL, width=2, dash=(6,4))

        # 2. Wieże i Strażnicy
        for i, straznik in enumerate(self.wieze_straznicy):
            px, py = self._przelicz_koordynaty(straznik.x, straznik.y)
            r = 7
            
            if self.img_kopalnia: # Jeśli obrazki się wczytały
                if straznik.id == self.id_wygranego_straznika:
                    c.create_image(px, py, image=self.img_wieza_atak)
                    # Zostawiamy dymek z rozkazem
                    c.create_rectangle(px-20, py-35, px+110, py-18, fill="#ef4444", outline="")
                    c.create_text(px+45, py-26, text="📢 NA CIĘCIWY!", fill="white", font=("Segoe UI", 7, "bold"))
                else:
                    c.create_image(px, py, image=self.img_wieza)
            else: # Stary kod jako awaryjny fallback
                if straznik.id == self.id_wygranego_straznika:
                    c.create_oval(px-15, py-15, px+15, py+15, outline="#ef4444", width=2)
                    c.create_polygon(px, py-r-4, px+r+4, py+r, px-r-4, py+r, fill="#ef4444")
                else:
                    c.create_polygon(px, py-r, px+r, py+r, px-r, py+r, fill="#a78bfa", outline="#6d28d9")
                    
            c.create_text(px, py+r+12, text=f"W_{i} (G:{straznik.glosnosc})", fill="#e2e2e2", font=("Segoe UI", 7))
        # 3. Górnicy
        for kr in self.krasnale_gornicy:
            px, py = self._przelicz_koordynaty(kr.x, kr.y)
            if self.img_kopalnia:
                c.create_image(px, py, image=self.img_gornik)
            else:
                c.create_oval(px-3, py-3, px+3, py+3, fill=COLOR_DWARF, outline="")
        # 4. Kopalnie
        for k in self.kopalnie:
            px, py = self._przelicz_koordynaty(k.x, k.y)
            r = 6 + k.wydajnosc
            
            if self.img_kopalnia:
                c.create_image(px, py, image=self.img_kopalnia)
            else:
                c.create_rectangle(px-r, py-r, px+r, py+r, fill=COLOR_MINE, outline="#b45309")
                
            c.create_text(px, py-r-10, text=k.nazwa, fill=COLOR_MINE, font=("Segoe UI", 8, "bold"))
    def _pokaz_okienko_info(self, x, y, tytul, linie, kolor_akcentu):
        """Rysuje ładny, lewitujący pop-up z informacjami na mapie."""
        # Usuwamy poprzednie okienko, żeby nie nakładały się na siebie
        self.canvas.delete("tooltip")
        
        # Obliczamy wymiary okienka dynamicznie
        szerokosc = 180
        wysokosc = 30 + len(linie) * 20
        
        # Lekkie przesunięcie, żeby okienko nie zasłaniało samego obiektu i kursora
        x_okna = x + 15
        y_okna = y - 10
        
        # Rysujemy tło okienka (z tagiem "tooltip", żeby móc je łatwo usuwać)
        self.canvas.create_rectangle(
            x_okna, y_okna, x_okna + szerokosc, y_okna + wysokosc,
            fill="#252538", outline=kolor_akcentu, width=2, tags="tooltip"
        )
        
        # Rysujemy tytuł (np. nazwa kopalni/krasnala)
        self.canvas.create_text(
            x_okna + 10, y_okna + 15,
            text=tytul, fill=kolor_akcentu, font=("Segoe UI", 10, "bold"), anchor=tk.W, tags="tooltip"
        )
        
        # Rysujemy parametry pod spodem
        for i, linia in enumerate(linie):
            self.canvas.create_text(
                x_okna + 10, y_okna + 35 + (i * 18),
                text=linia, fill="#e2e2e2", font=("Segoe UI", 8), anchor=tk.W, tags="tooltip"
            )    
    
    def _start_pan(self, event):
        # --- DODAJ TĘ LINIJKĘ: Usuń okienko przy każdym nowym kliknięciu ---
        self.canvas.delete("tooltip") 
        
        self.pivot_x = event.x
        self.pivot_y = event.y
        ex, ey = event.x, event.y

        # Sprawdzamy kopalnie (kwadraty)
        for k in self.kopalnie:
            px, py = self._przelicz_koordynaty(k.x, k.y)
            r = 6 + k.wydajnosc
            if abs(px - ex) <= r and abs(py - ey) <= r:
                linie = [f"Minerał: {k.mineral.capitalize()}", f"Wydajność: {k.wydajnosc} j."]
                self._pokaz_okienko_info(ex, ey, f"⛏️ {k.nazwa}", linie, COLOR_MINE)
                return

        # Sprawdzamy strażników (trójkąty na granicy)
        for straznik in self.wieze_straznicy:
            px, py = self._przelicz_koordynaty(straznik.x, straznik.y)
            if abs(px - ex) <= 10 and abs(py - ey) <= 10:
                linie = [f"Głośność: {straznik.glosnosc} dB", "Status: Na warcie"]
                self._pokaz_okienko_info(ex, ey, f"🛡️ {straznik.imie}", linie, "#ef4444")
                return

        # Sprawdzamy zwykłych górników (niebieskie kropki)
        for kr in self.krasnale_gornicy:
            px, py = self._przelicz_koordynaty(kr.x, kr.y)
            if abs(px - ex) <= 5 and abs(py - ey) <= 5:
                umiej = ", ".join(kr.umiejetnosci) if kr.umiejetnosci else "Brak"
                linie = [f"Fach: {umiej}"]
                self._pokaz_okienko_info(ex, ey, f"🧔 {kr.imie}", linie, COLOR_DWARF)
                return

    def _ogranicz_kamere(self):
        """Utrzymuje kamerę w ryzach, żeby nie wyleciała poza plik tła."""
        szer = self.canvas.winfo_width()
        wys = self.canvas.winfo_height()
        
        # Rozmiar tła mapy (zgodnie z tym, co wpisaliśmy przy wczytywaniu)
        img_w = 1920
        img_h = 1080
        
        # Maksymalne dozwolone przesunięcie w pikselach
        max_pan_x = max(0, (img_w - szer) / 2)
        max_pan_y = max(0, (img_h - wys) / 2)
        
        # Ucinamy (clamp) pozycję kamery, żeby nie przekroczyła limitów
        self.pan_x = max(-max_pan_x, min(self.pan_x, max_pan_x))
        self.pan_y = max(-max_pan_y, min(self.pan_y, max_pan_y))

    def _execute_pan(self, event):
        self.pan_x += event.x - self.pivot_x
        self.pan_y += event.y - self.pivot_y
        self.pivot_x = event.x
        self.pivot_y = event.y
        
        # Odpalamy ograniczenie przed rysowaniem!
        self._ogranicz_kamere() 
        self.odswiez_mape()

    def _execute_zoom(self, event):
        self.zoom *= 1.1 if event.delta > 0 else (1/1.1)
        # Zmieniamy minimalny zoom na 0.9, żeby krasnale nie zbiły się w malutką kropkę
        self.zoom = max(0.9, min(self.zoom, 15.0)) 
        
        self._ogranicz_kamere()
        self.odswiez_mape()
        
    def _animuj_atak(self):
        """Prosta animacja pulsującego okręgu wokół krzyczącego krasnala."""
        if not self.id_wygranego_straznika:
            return
            
        # Zmieniamy rozmiar pulsującego okręgu (od 15 do 25 i z powrotem)
        if not hasattr(self, 'promien_animacji') or self.promien_animacji > 25:
            self.promien_animacji = 15
            self.kierunek_anim = 1
        
        self.promien_animacji += self.kierunek_anim
        if self.promien_animacji >= 25: self.kierunek_anim = -1
        if self.promien_animacji <= 15: self.kierunek_anim = 1
        
        # Odświeżamy mapę, żeby narysować klatkę animacji
        self.odswiez_mape()
        
        # Odpal tę samą funkcję za 50 ms (co daje ~20 FPS)
        self.root.after(50, self._animuj_atak)
    # ==========================================
    #             TESTY WYDAJNOŚCIOWE
    # ==========================================
    def _otworz_benchmark(self):
        """Otwiera nowe okno przeznaczone wyłącznie do surowych testów obliczeniowych."""
        okno = tk.Toplevel(self.root)
        okno.title("Benchmark - Testy Wielkoskalowe")
        okno.geometry("500x650")
        okno.configure(bg=BG_MAIN)
        
        tk.Label(okno, text="🔥 SUROWE TESTY OBLICZENIOWE 🔥", bg=BG_MAIN, fg=ACCENT, font=("Segoe UI", 16, "bold")).pack(pady=15)
        
        ramka = tk.Frame(okno, bg=BG_PANEL, padx=20, pady=20)
        ramka.pack(fill=tk.X, padx=20)
        
        tk.Label(ramka, text="Liczba kopalń (np. 100 000):", bg=BG_PANEL, fg=TEXT_COLOR).grid(row=0, column=0, sticky=tk.W, pady=5)
        pole_kop = tk.Entry(ramka, bg=BG_MAIN, fg=TEXT_COLOR, insertbackground=TEXT_COLOR, font=("Segoe UI", 12))
        pole_kop.insert(0, "100000")
        pole_kop.grid(row=0, column=1, pady=5)
        
        tk.Label(ramka, text="Liczba górników (np. 1 000 000):", bg=BG_PANEL, fg=TEXT_COLOR).grid(row=1, column=0, sticky=tk.W, pady=5)
        pole_gorn = tk.Entry(ramka, bg=BG_MAIN, fg=TEXT_COLOR, insertbackground=TEXT_COLOR, font=("Segoe UI", 12))
        pole_gorn.insert(0, "1000000")
        pole_gorn.grid(row=1, column=1, pady=5)
        
        tk.Label(ramka, text="Liczba ataków (Drzewo):", bg=BG_PANEL, fg=TEXT_COLOR).grid(row=2, column=0, sticky=tk.W, pady=5)
        pole_ataki = tk.Entry(ramka, bg=BG_MAIN, fg=TEXT_COLOR, insertbackground=TEXT_COLOR, font=("Segoe UI", 12))
        pole_ataki.insert(0, "50000")
        pole_ataki.grid(row=2, column=1, pady=5)

        wyniki_text = tk.Text(okno, bg="#11111b", fg=COLOR_HULL, font=("Consolas", 10), height=15)
        wyniki_text.pack(fill=tk.BOTH, expand=True, padx=20, pady=15)
        
        # Przekazujemy zmienne do funkcji liczącej za pomocą lambdy
        ttk.Button(okno, text="Uruchom Benchmark", style="Hero.TButton", 
                   command=lambda: self._uruchom_testy(pole_kop.get(), pole_gorn.get(), pole_ataki.get(), wyniki_text, okno)).pack(pady=10)

    def _uruchom_testy(self, str_kop, str_gorn, str_ataki, pole_wynikow, okno):
        try:
            n_kop = int(str_kop)
            n_gorn = int(str_gorn)
            n_ataki = int(str_ataki)
        except ValueError:
            messagebox.showerror("Błąd", "Wprowadź poprawne liczby całkowite!")
            return

        pole_wynikow.delete(1.0, tk.END)
        pole_wynikow.insert(tk.END, f"Rozpoczynam test dla {n_kop} kopalń i {n_gorn} krasnali...\n")
        pole_wynikow.insert(tk.END, "PROSZĘ CZEKAĆ (Aplikacja może na chwilę 'zamarznąć')...\n\n")
        okno.update() # Wymusza odświeżenie okna, żeby pokazał się napis zanim Python zablokuje wątek
        
        # 1. GENEROWANIE DANYCH
        t_start = time.perf_counter()
        kopalnie_test = generuj_kopalnie(n_kop, seed=None)
        krasnale_test = generuj_krasnoludki(n_gorn, kopalnie_test, seed=None)
        t_gen = time.perf_counter() - t_start
        pole_wynikow.insert(tk.END, f"[✓] Generowanie danych: {t_gen:.4f} sekundy\n")
        okno.update()

        # 2. ALGORYTM GRAHAMA I WIEŻE
        t_start = time.perf_counter()
        otoczka_test = graham(kopalnie_test)
        wieze_test = wyznacz_wieze_straznicze(otoczka_test)
        t_graham = time.perf_counter() - t_start
        pole_wynikow.insert(tk.END, f"[✓] Graham i {len(wieze_test)} wież: {t_graham:.4f} sekundy\n")
        okno.update()

        # 3. BUDOWA DRZEWA PRZEDZIAŁOWEGO
        t_start = time.perf_counter()
        drzewo_test = DrzewoPrzedzialowe(wieze_test)
        t_drzewo_budowa = time.perf_counter() - t_start
        pole_wynikow.insert(tk.END, f"[✓] Budowa Drzewa (O(N)): {t_drzewo_budowa:.4f} sekundy\n")
        okno.update()

        # 4. MASOWE ZAPYTANIA DO DRZEWA
        t_start = time.perf_counter()
        if len(wieze_test) > 0:
            for _ in range(n_ataki):
                q_s = random.randint(0, len(wieze_test) - 1)
                q_e = random.randint(0, len(wieze_test) - 1)
                _ = drzewo_test.znajdz_najglosniejszego(q_s, q_e)
        t_drzewo_zapytania = time.perf_counter() - t_start
        pole_wynikow.insert(tk.END, f"[✓] {n_ataki} zapytań RMQ (O(log N)): {t_drzewo_zapytania:.4f} sekundy\n")
        okno.update()

        # Omijamy wykresy dla Dinica, jeśli liczb jest za dużo
        calkowity_czas = t_gen + t_graham + t_drzewo_budowa + t_drzewo_zapytania
        pole_wynikow.insert(tk.END, f"\n🚀 CAŁKOWITY CZAS (Bez grafów): {calkowity_czas:.4f} sekundy\n")
        if n_kop + n_gorn > 5000:
            pole_wynikow.insert(tk.END, "\n⚠️ Pominięto algorytm Dinica/Bellmana-Forda. Przydział powyżej 5000 elementów zablokowałby komputer.")
        
        pole_wynikow.see(tk.END)

if __name__ == "__main__":
    baza = tk.Tk()
    app = NowaAplikacjaGUI(baza)
    baza.mainloop()