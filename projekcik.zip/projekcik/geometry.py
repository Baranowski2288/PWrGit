"""
Modul odpowiedzialny za algorytmy z zakresu geometrii obliczeniowej.

Zawiera implementacje:
1. Algorytmu Grahama - sluzacego do wyznaczania otoczki wypuklej z pominieciem trygonometrii.
   Wykorzystuje orientacje wyznacznika na znakach punktow przy sortowaniu biegunowym i iteracji ze stosem.
"""


from functools import cmp_to_key

def _wyznacznik(p0, pi, pj):
    # det > 0 skret w lewo, det < 0 skret w prawo, det == 0 wspolliniowosc
    return (pi.x - p0.x) * (pj.y - p0.y) - (pj.x - p0.x) * (pi.y - p0.y)

def _odleglosc_kw(p0, pi):
    return (pi.x - p0.x) ** 2 + (pi.y - p0.y) ** 2

def graham(punkty):
    if len(punkty) < 3:
        return list(punkty)

    p0 = min(punkty, key=lambda p: (p.y, p.x))
    reszta = [p for p in punkty if p is not p0]

    def porownaj_katowo(pi, pj):
        det = _wyznacznik(p0, pi, pj)
        if det > 0:
            return -1
        if det < 0:
            return 1
            
        di = _odleglosc_kw(p0, pi)
        dj = _odleglosc_kw(p0, pj)
        return -1 if di < dj else (1 if di > dj else 0)

    reszta.sort(key=cmp_to_key(porownaj_katowo))

    # inicjalizacja stosu samym p0
    # petla glowna sama usunie zbedne wspolliniowe punkty dzieki det <= 0
    stos = [p0]
    
    for pi in reszta:
        while len(stos) > 1 and _wyznacznik(stos[-2], stos[-1], pi) <= 0:
            stos.pop()
        stos.append(pi)

    return stos
